#include<stdio.h>
void main()
{
	int arr[30];
	int i,minpos,n,j,swap;
	printf("\nHow Many Elements :");
	scanf("%d",&n);
	printf("\nEnter Elements : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n-1;i++)
	{
		minpos = i;
		for(j=i+1;j<n;j++)
		{
			if(arr[minpos] > arr[j])
			{
				 minpos = j;
			}
			if(minpos != i)
			{
				swap = arr[i];
				arr[i] = arr[minpos];
				arr[minpos] = swap;
			}
		}

	}
	printf("\nShorted Elements : ");
	for(i=0;i<n;i++)
		printf("%d\t",arr[i]);
}
