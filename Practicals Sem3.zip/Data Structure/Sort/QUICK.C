#include<stdio.h>
#include<conio.h>
void Quicksort(int arr[],int first,int last)
{

	int i,j,pivot,temp;

	if(first<last)
	{
		pivot = first;
		i=first;
		j=last;
	while(i<j){
	while(arr[i]<=arr[pivot] && i<last)
	{
		i++;
	}
	while(arr[pivot]<arr[j] )
	{
			j--;
	}
	if(i<j)
	{
		temp=arr[i];
		arr[i]= arr[j];
		arr[j]= temp;
	}
	}
	temp = arr[pivot];
	arr[pivot] = arr[j];
	arr[j] = temp;
	Quicksort(arr,first,j-1);
	Quicksort(arr,j+1,last);
	}
}

void main()
{
	//int arr[30],i,no;
	int arr[30];
	int no;
	int i;
	clrscr();
	printf("\nHow many Elements : ");
	scanf("%d",&no);
	printf("\nEnter Elements : ");
	for(i=0;i<no;i++)
	{
		scanf("%d",&arr[i]);
	}
	Quicksort(arr,0,4);
	printf("\nEntered Elements : ");
	for(i=0;i<no;i++)
	{
		printf("%d\t",arr[i]);
	}
}