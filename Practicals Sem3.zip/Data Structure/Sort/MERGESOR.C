#include<stdio.h>
#include<conio.h>
void merge(int arr[],int l,int mid,int r)
{

	int n1=mid-l+1,n2=r-mid,i,j,k;
	int a[n1];
	int b[n2];
	//n1 = mid-l+1;
	//n2 = r-mid;
	for(i=0;i<n1;i++)
{
	a[i] = arr[l+i];
}

	for(i=0;i<n1;i++)
{
	a[i] = arr[mid+1+i];
}
	i=0;
	j=0;
	k=l;

	while(i<n1 && j<n2)
	{
		if(a[i]<b[j])
		{
			arr[k] = a[i];
			k++;
			i++;
		}
		else
		{
			arr[k] = a[j];
			k++;
			i++;
		}
	}
	while(i<n1)
	{
		arr[k] = a[i];
		k++;
		i++;
	}
		while(j<n2)
	{
		arr[k] = a[j];
		k++;
		i++;
	}
}

void mergeSort(int arr[],int l,int r)
{
	if(l<r)
	{
		int mid = (l+r)/2;
		mergeSort(arr,l,mid);
		mergeSort(arr,mid+1,r);

		merge(arr,l,mid,r);
	}
}
void main()
{
	int arr[50],no;
	int i;
	printf("\nHow Many Elements? : ");
	scanf("%d",&no);
	printf("\nEnter Elements : ");
	for(i=0;i<no;i++)
	{
		scanf("%d",&arr[i]);
	}
	mergeSort(arr,0,no);
	printf("\nShorted Elements : ");
	for(i=0;i<no;i++)
	{
		printf("%d\t",arr[i]);

	}
}