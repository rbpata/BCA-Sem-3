//Array Shorting With DataStructure & Algorithms
#include<stdio.h>
void main()
{
	int n[30];
	int num,i,j,temp;
	clrscr();
	printf("\nEnter Size of Array :");
	scanf("%d",&num);
	printf("\nEnter Elements :");
	for(i=0;i<num;i++)
		scanf("%d",&n[i]);
	for(i=0;i<num;++i)
	{
		for(j=i+1;j<num;++j)
		{
			if(n[i]>n[j])
			{
				temp=n[i];
				n[i]=n[j];
				n[j]=temp;
			}
		}
	}
	printf("\nShorted Elements are : ");
	for(i=0;i<num;i++)
	{
		printf(" %d  ",n[i]);
	}
	printf("\n\n---------------------The End--------------------\n");
}


