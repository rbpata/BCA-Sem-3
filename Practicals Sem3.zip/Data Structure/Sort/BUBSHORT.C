//Bubshort
#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i,temp,count=1;
	int arr[30];
	clrscr();
	printf("\nEnter Size Of Array :");
	scanf("%d",&n);
	printf("\nEnter Elemnts :");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	while(count<n)
	{
		for(i=0;i<n-count;i++)
		{
			if(arr[i]>arr[i+1])
			{
				temp = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = temp;
			}
		}
		count++;
}

	printf("\nShorted Element is :  ");
	for(i=0;i<n;i++)
		printf(" %d  ",arr[i]);
}