//Array Shorting With DataStructure & Algorithms
#include<stdio.h>
void main()
{
	int n[30];
	int num,i,j,temp,flag=0;
	int found,high,low,mid;
	clrscr();
	printf("\nEnter Size of Array :");
	scanf("%d",&num);
	printf("\nEnter Elements :");
	for(i=0;i<num;i++)
		scanf("%d",&n[i]);
	for(i=0;i<num;++i)
	{
		for(j=i+1;j<num;++j)
		{
			if(n[i]>n[j])
			{
				temp=n[i];
				n[i]=n[j];
				n[j]=temp;
			}
		}
	}
	printf("\nShorted Elements are : ");
	for(i=0;i<num;i++)
	{
		printf(" %d  ",n[i]);
	}
	//printf("\n\n---------------------The End--------------------\n");
	printf("\nEnter Element you Want to search :");
	scanf("%d",&found);
	low=0;
	high=num-1;

	while(low<=high)
	{
		mid = (low+high)/2;
		if(n[mid]<found)
		{
			low=mid+1;

		}
		if(n[mid]==found)
		{
			flag =1;
			break;
			}
		else

		{
			high= mid +1;

		}

	}
	if(flag==1)
	printf("\nPosition = %d",mid+1);
	else
	printf("\nNot Found..");
}


