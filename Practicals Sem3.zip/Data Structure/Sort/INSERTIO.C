//insertion sort
#include<stdio.h>
void main()
{
	int arr[20];
	int i,j,current,n;
	printf("\nHow Many Elements : ");
	scanf("%d",&n);
	printf("\nEnter Elements : ");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	for(i=1;i<n;i++)
	{
		current = arr[i];
		j = i-1 ;
		while(current < arr[j] && j>=0)
		{
			arr[j+1] = arr[j];
			j--;

		}
		arr[j+1] = current ;

	}
	printf("\nShorted Elements : ");
	for(i=0;i<n;i++)
		printf("%d\t",arr[i]);

}