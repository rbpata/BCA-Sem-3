#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define size 100
int arr[size];
int f=-1;
int r=-1;
void Enqueue();
void Dequeue();
void Display();
void main()
{
	int choice=0;
	while(choice != 4)
	{
		printf("\n1 insert... \n2 delete...  \n3 Display... \n4.exit..");
		printf("\nEnter Your Choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: Enqueue();
				break;
			case 2: Dequeue();
				break;
			case 3: Display();
				break;
			case 4: exit(0);
				break;

		}
	}
}
void Enqueue()
{
	int val;
	if(r == size-1)
	{
		printf("\nOverflow..");
	}
	else
	{
		if(f == -1)
			f = 0;
		printf("\nEnter the value you want to insert..");
		scanf("%d",&val);
		r = r+1;
		arr[r] = val;
	}
}
void Dequeue()
{
	if(f == -1 || f > r)
	{
		printf("\nUnderflow..");
	}
	else
	{
		printf("Element Deleted From THe Queue : %d",arr[f]);
		f = f+1;
	}
}
void Display()
{
	int i;
	if(f == -1)
	{
		printf("\nEmpty..");
	}
	else
	{
		printf("\nQueue Elements : [ ");
		for(i=f;i<=r;i++)
		{
			printf("%d ",arr[i]);
		}
		printf(" ]");
	}
}
