#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct Stack{

	int data;
	struct Stack * next;
};
struct Stack * top;
void Push();
void Pop();
void Peep();
void Display();
void main()
{


	int ch=0;
	clrscr();
	while(ch != 5)
	{
	printf("\n1 : Push(); \n2 : Pop(); \n3 : Peep(); \n4 : Display(); \n5 : Exit();");
	printf("\nEnter your Choise : ");
	scanf("%d",&ch);
		switch(ch)
		{

		case 1 :
			Push();
			break;
		case 2 :

			Pop();
			break;
		case 3 :
			Peep();
			break;
		case 4 :Display();
			break;
		case 5 : exit(0);
		}
	}
}
void Push()
{
	int no;
	struct Stack * ptr;
	ptr = (struct Stack *) malloc (sizeof(struct Stack *));

	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
		printf("\nenter Value : ");
		scanf("%d",&no);

	ptr->data=no;
	ptr->next=top;
	top = ptr ;
	printf("\n");
	}

}
void Pop()
{
	struct Stack * ptr;
	if(top==NULL)
	{

		ptr->next = NULL;
		top = ptr ;
		printf("\n");
	}
	else
	{
		ptr = top;
		printf("\nPoped Elemnet is : %d \n",ptr->data);
		top = ptr->next;
		free(ptr);
	}

}
void Peep()
{
	printf("\nThe Top Most Element is : %d \n",top->data);
}
void Display()
{
	struct Stack * ptr = top;
	printf("\nData :[ ");
	while(ptr != NULL)
	{

		printf("%d  ",ptr->data);
		ptr = ptr->next;
	}
	printf("]\n\n");
}

