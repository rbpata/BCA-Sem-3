#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node * next;
};
struct node * f=NULL;
struct node * r=NULL,*temp;
void Enqueue()
{
	int val;
	struct node * ptr;
	ptr= (struct node *) malloc (sizeof(struct node));

		printf("\nEnter Value You Want to Insert : ");
		scanf("%d",&val);
		ptr->data = val;
		ptr->next = NULL;
		if(f == NULL)
		{
			f = r = ptr;
		}
		else
		{
			r->next = ptr;
		}
		r=ptr;
}
void Dequeue()
{
	struct node *temp= f;
	if(r == NULL)
{
		printf("\nUNderflow...");
	}
	else
	{
		printf("\nDeleted Element is  : %d",temp->data);
		f = f->next;
		free(temp);
	}

}
void Display()
{
	if(f== NULL)
	{
			printf("\nUNderflow...");
	}
	else
	{
	printf("\n[ ");
temp=f;
while(temp)
{
	printf("%d\t",temp->data);
	temp=temp->next;
	}
	printf(" ]");
	}
}
void main()
{
	int choice=0;
	while(choice != 4)
	{
		printf("\n1.Enqueue \n2.Dequeue \n3.Display \n4.Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1 :Enqueue();
				break;
			case 2 :Dequeue();
				break;
			case 3 :Display();
				break;
			case 4 :exit(0);
				break;
		}
	}
}