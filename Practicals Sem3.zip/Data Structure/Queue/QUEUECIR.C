#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node * next;
};
struct node *f=NULL;
struct node *r=NULL,*temp,*ptr;
void Enqueue()
{
	ptr= (struct node *) malloc (sizeof(struct node));

		printf("\nEnter Value You Want to Insert : ");
		scanf("%d",&ptr->data);
		ptr->next = f;
		if(f == NULL)
		{
			f = r = ptr;
		}
		else
		{
			r->next = ptr;
			r=ptr;
		}

}
void Dequeue()
{            if(f==NULL)
  printf("\nUnder flow:");
	else if(r == r->next)
	 {
	 f=r=NULL;
	 }
	else
	{

		temp=f;
		 printf("\nDeleted Element is  : %d",temp->data);
		r->next = f->next;
		f=f->next;
		free(temp);
	}

}
void Display()
{
	if(f==NULL)
	{
			printf("\nUNderflow...");
	}
	else
	{ temp=f;
	 do
	 {    printf("%d\t",temp->data);
	   temp=temp->next;
	 }while(temp!=f);
	}
}
void main()
{
	int choice;
	do
	{
		printf("\n1.Enqueue \n2.Dequeue \n3.Display\n4.exit");
		printf("\nEnter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1 :Enqueue();
				break;
			case 2 :Dequeue();
				break;
			case 3 : Display();
				break;
			case 4:break;

		}
	}while(choice!=4);
}