#include<stdio.h>
#include<conio.h>
void main()
{
	int no;
	printf("Enter The Size Of Array You Want to Store:\n");
	scanf("%d",&no);
	int * ptr;
	ptr= (int *)malloc(n * sizeof(int));
	printf("Enter Elements..\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&n[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("Entered Element are : %d",n[i]);
	}


}