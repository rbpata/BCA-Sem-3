#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node{

	int data;
	struct node * next;
	struct node * prev;
};
struct node* head;
void newNode();
void InAtEnd();
void display();
void InBfrPos();
void InAftrPos();
void dltAtFirst();
void dltAtLast();
void dltBfrPos();
void dltAftrPos();
void main()
{


	int ch=0;
	clrscr();
	while(ch != 8)
	{
	printf("\n1 : Insert a Node at First Position \n2 : Display.. \n3 : Insert Node AT the End.. \n4 : Insert Before Desire Position \n5 : Insert After Desire Position.. \n6 : Delete The First Node.. \n7 : Delete THe last Node.. \n8 : Delete node Before Desire Position.. \n9 : Delete a NOde After Desire POsition.. \n10 : Exit.. ");
	printf("\nEnter your Choise : ");
	scanf("%d",&ch);
		switch(ch)
		{

		case 1 :
			newNode();
			break;
		case 2 :

			display();
			break;
		case 3 :
			InAtEnd();
			break;
		case 4 :
			InBfrPos();
			break;
		case 5 :
			InAftrPos();
			break;
		case 6 :
			dltAtFirst();
			break;
		case 7 :\
			dltAtLast();
			break;
		case 8 :dltBfrPos();
			break;
		case 9 :
			dltAftrPos();
			break;
		case 10 : exit(0);
		}


	}


}
void newNode()
{
	int no;
	struct node * ptr;
	ptr = (struct node *) malloc (sizeof(struct node *));

	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
		printf("\nenter Value : ");
		scanf("%d",&no);

	ptr->data = no;
	ptr->next = head;
	ptr->prev = NULL;
	head = ptr ;
	printf("\n");
	}

}

void InAtEnd()
{
	 int no;
	struct node * ptr;
	struct node * tmp;
	ptr = (struct node *) malloc (sizeof(struct node *));

	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
		printf("\nenter Value : ");
		scanf("%d",&no);
		ptr->data = no;
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{
		tmp=head;
		while(tmp->next != NULL)
		{
			tmp=tmp->next;
		}
		tmp->next = ptr;
		ptr->prev = tmp;
		ptr->next = NULL;
		printf("\n");
	}
	}

}
void InBfrPos()
{
	int no,pos;
	struct node * ptr;
	struct node * tmp1;
	struct node * tmp2;
	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
	printf("\nEnter Value : ");
	scanf("%d",&no);
	ptr = (struct node *) malloc (sizeof(struct node *));
	printf("\nEnter That value Before You Want to INsert Node : ");
	scanf("%d",&pos);
	ptr->data = no;
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{

		tmp1=head;
		tmp2=head;
		while(tmp1->data != pos)
		{
			tmp2 = tmp1;
			tmp1=tmp1->next;
		}
		tmp2->next = ptr;
		ptr->next = tmp1;
		printf("\n");
	}
	}

}

void InAftrPos()
{
	int no,pos;
	struct node * ptr;
	struct node * tmp1;
	struct node * tmp2;
	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
	printf("\nEnter Value : ");
	scanf("%d",&no);
	printf("\nEnter That value after You Want to INsert Node : ");
	ptr = (struct node *) malloc (sizeof(struct node *));
	scanf("%d",&pos);
	ptr->data = no;
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{
		tmp1=head;
		while(tmp1->data != pos)
		{
			tmp1=tmp1->next;
		}
		tmp2=tmp1->next;
		tmp1->next = ptr;
		ptr->next = tmp2;
		printf("\n");
	}
	}

}
void dltAtFirst()
{
	struct node * ptr;
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{
		ptr = head;
		head = ptr->next;
		free(ptr);
	}

}
void dltAtLast()
{
	struct node * ptr;
	struct node * tmp;
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{
		ptr = head;
		while(ptr->next != NULL)
		{
			tmp = ptr;
			ptr = ptr->next;
		}
		tmp->next = NULL;
		free(ptr);
	}

}
void dltBfrPos()
{
	int pos;
	struct node * ptr;
	struct node * tmp1;
	struct node * tmp2;
	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
	printf("\nEnter That value Before You Want to Delete a Node : ");
	scanf("%d",&pos);
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{

		tmp1=head;
		tmp2=head;
		while(tmp1->data != pos)
		{
			tmp2 = tmp1;
			tmp1=tmp1->next;
		}
		tmp2->next = tmp1->next;
		free(tmp1);
		printf("\n");
	}
	}

}
void dltAftrPos()
{
	int pos;
	struct node * ptr;
	struct node * tmp1;
	struct node * tmp2;
	if(ptr == NULL)
	{
		printf("\nERROR");
	}
	else
	{
	printf("\nEnter That value After You Want to Delete a Node : ");
	scanf("%d",&pos);
	if(head==NULL)
	{

		ptr->next = NULL;
		head = ptr ;
		printf("\n");
	}
	else
	{

		tmp1=head;
		tmp2=head;
		while(tmp1->data != pos)
		{

			tmp1=tmp1->next;
		}
		tmp2= tmp1->next;
		tmp1->next = tmp2->next;
		free(tmp2);
		printf("\n");
	}
	}

}

void display()
{
	struct node * ptr = head;
	printf("\nData :[ ");
	while(ptr != NULL)
	{

		printf("%d  ",ptr->data);
		ptr = ptr->next;
	}
	printf("]\n\n");
}
