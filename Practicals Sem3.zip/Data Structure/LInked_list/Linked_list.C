#include<stdio.h>
#include<conio.h>
void insert();
void del();
void insert_beg();
void insert_end();
void insert_before();
void insert_after();
void del_beg();
void del_end();
void del_before();
void del_give();
void del_after();
void display();
struct node
{ int data;
     struct node *next;

};
typedef struct node node;
node *start=NULL,*temp,*New,*det,*pr;
int cnt=0;
void main()
{ int ch;
do
{
 printf("\n:::::::::MAIN MENU:::::::::");
 printf("\n1.insertion\n2.delete\n3.display\n4.exit");
   printf("\nEnter your choice::");
   scanf("%d",&ch);
   switch(ch)
   { 	case 1:insert();
		break;
	case 2:del();
		break;
	case 3:display();
		break;
	case 4:exit(1);

   }
 }while(ch!=4);

}
void insert()
{ int ch;
  do
  {       printf("\n:::::::::INSERTION MENU:::::::::");
  printf("\n1.insert at begnning \n2.insert at end\n3.insert node before\n4.insert node after\n5.display\n6.exit\nenter your choice:");
  scanf("%d",&ch);
  switch(ch)
  { 	 case 1:insert_beg();
		cnt++;
		break;
	case 2:insert_end();
		cnt++;
		break;
	case 3:insert_before();
		cnt++;
		break;
	case 4:insert_after();
		cnt++;
		break;
	case 5:display();
		break;
	case 6:break;

  }

  }while(ch!=6);

}
void del()
{ int ch;
  do
  {   printf("\n:::::::::DELETE MENU:::::::::");
  printf("\n1.delete at begnning \n2.delete at end\n3.detele node given value\n4.delete node after\n5.display\n6.exit\nenter your choice:");
  scanf("%d",&ch);
  switch(ch)
  { 	 case 1:del_beg();
		cnt--;
		break;
	case 2:del_end();
		cnt--;
		break;
	case 3:del_give();
		cnt--;
		break;
	case 4:del_after();
		cnt--;
		break;
	case 5:display();
		break;
	case 6:break;
  }

  }while(ch!=6);

}


void insert_beg()
{ New=(node*)malloc(sizeof(node));
  printf("Enter data:");
  scanf("%d",&New->data);
     New->next=start;
     start=New;
}
void insert_end()
{ New=(node*)malloc(sizeof(node));
  printf("Enter data:");
  scanf("%d",&New->data);
  New->next=NULL;
  for(temp=start;temp->next!=NULL;temp=temp->next);
  temp->next=New;
}
void insert_before()
{
  int val;
  New=(node*)malloc(sizeof(node));
  printf("\nwhere node:");
  scanf("%d",&val);
  printf("Enter data:");
  scanf("%d",&New->data);
  for(temp=start;temp->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  New->next=temp;
  pr->next=New;

}
void insert_after()
{ int val;
  New=(node*)malloc(sizeof(node));
  printf("\nwhere node:");
  scanf("%d",&val);
  printf("Enter data:");
  scanf("%d",&New->data);
  for(temp=start;pr->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  New->next=temp;
  pr->next=New;

}
void del_beg()
{ temp=start;
  start=start->next;
  free(temp);
}
void del_end()
{  for(temp=start;temp->next->next!=NULL;temp=temp->next);
    det=temp->next;
    temp->next=NULL;
    free(del);
}
void del_after()
{  int val;
   printf("\nwhere node:");
    scanf("%d",&val);
    for(temp=start;pr->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  pr->next=temp->next;
  free(temp);
}
void del_give()
{ int val;
  printf("\nEnter node to delete");
  scanf("%d",&val);
  if(start->data==val)
  { temp=start;
   start=start->next;
   free(temp);

  }
  else
  {
	 for(temp=start;temp->data!=val;temp=temp->next)
	 {
	 pr=temp;
	 }
  pr->next=temp->next;
  free(temp);
  }
}
void display()
{ for(temp=start;temp!=NULL;temp=temp->next)
  printf("\ndata: %d",temp->data);

}


