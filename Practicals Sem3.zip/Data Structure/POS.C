#include<stdio.h>
void main()
{
	int no[5];
	int i,temp,New;
	for(i=0;i<5;i++)
	{
		printf("Enter The %d Element",i+1);
		scanf("%d",&no[i]);
	}
	printf("\nEnter No You Want to Search The Position Of");
	scanf("%d",&temp);
	for(i=0;i<5;i++)
	{
		if(no[i]==temp);
		{
			printf("The position is:%d",i+1);
		}
	}
}