#include<stdio.h>
#include<conio.h>
#define size 5
int top=-1;
int arr[size];
void Push()
{
	int val;
	if(top == size-1)
	{
		printf("\nOverflow..");
	}
	else
	{

		top=top+1;
		arr[top]=val;
	}
}
void Pop()
{
	if(top == -1)
	{
		printf("\nUnderflow..");
	}
	else
	{
		printf("\nPoped Element was %d ",arr[top]);
		top=top-1;
	}
}
void Peep()
{
	if(top == -1)
	{
		printf("\nUnderflow..");
	}
	else
	{
		printf("\nTop most Element is : %d ",arr[top]);
	}
}
void Display()
{
	int i;
	printf("\nElemnet List : [ ");
	for(i=0;i<size;i++)
	{

		printf("  %d",arr[i]);
	}
}
void main()
{
	int choice,val;
	printf("\n1 : Push(); \n2 : Pop(); \n3 : Peep(); \n4 : Display(); \n5 : Exit();");
	printf("\nEnter Your Choice : ");
	scanf("%d",);
	do
	{
		switch(choice)
		{
			case 1 :
				printf("\nEnter Element You Want to Enter : ");
					scanf("%d",&val);
					Push();
					break;
			case 2 : Pop();
					break;
			case 3 : Peep();
					break;
			case 4 : Display();
					break;
			case 5 : exit(0);
					break;
			//default : printf("\nInvalid choise...");
			//	break;
		}
	}while(choice != 5);

}
