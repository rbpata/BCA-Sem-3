#include<iostream.h>
void main()
{
	int **p,i,j,m,n;
	int **p2,m2,n2;
	int **p3,m3,n3;
	cout<<"\nHow Many Raw?";
	cin>>m;
	cout<<"\nHow Many Colomns?";
	cin>>n;
	cout<<"\nHow Many Raw?";
	cin>>m;
	cout<<"\nHow Many Colomns?";
	cin>>n;
	p = new int *[m];
	for(i=0;i<m;i++)
	{
		p[i]=new int [n];
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cout<<"\n Enter"<<i<<","<<j<<"Elements value";
			cin>>p[i][j];

		}
	}
	p2 = new int *[m2];
	for(i=0;i<m2;i++)
	{
		p2[i]=new int [n2];
	}
	for(i=0;i<m2;i++)
	{
		for(j=0;j<n2;j++)
		{
			cout<<"\n Enter"<<i<<","<<j<<"Elements value";
			cin>>p2[i][j];

		}
	}
	p3 = new int *[m3];
	for(i=0;i<m2;i++)
	{
		p2[i]=new int [n2];
	}
	for(i=0;i<m2;i++)
	{
		for(j=0;j<n2;j++)
		{
			
			p3[i][j] = p2[i][j] + p[i][j];

		}
	}
	for(i=0;i<m2;i++)
	{
		for(j=0;j<n2;j++)
		{
			
			cout<<"Result Matrix = "<<p3[i][j];

		}
	}
	delete []p;
	delete p;

}
