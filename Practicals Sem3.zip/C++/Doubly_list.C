#include<stdio.h>
#include<conio.h>
void insert();
void del();
void insert_beg();
void insert_end();
void insert_before();
void insert_after();
void del_beg();
void del_end();
void del_before();
void del_give();
void del_after();
void display();
struct node
{ int data;
     struct node *next,*prev;

};
typedef struct node node;
node *start=NULL,*temp,*New,*det,*pr;
int cnt=0;
void main()
{ int ch;
do
{
 printf("\n:::::::::MAIN MENU:::::::::");
 printf("\n1.insertion\n2.delete\n3.display\n4.how many node are there\n5.exit");
   printf("\nEnter your choice::");
   scanf("%d",&ch);
   switch(ch)
   { 	case 1:insert();
		break;
	case 2:del();
		break;
	case 3:display();
		break;
	case 4:
		printf("\nThere are %d node",cnt);
		break;
	case 5:exit(1);

   }
 }while(ch!=5);

}
void insert()
{ int ch;
  do
  {       printf("\n:::::::::INSERTION MENU:::::::::");
  printf("\n1.insert at begnning \n2.insert at end\n3.insert node before\n4.insert node after\n5.display\n6.exit\nenter your choice:");
  scanf("%d",&ch);
  switch(ch)
  { 	 case 1:insert_beg();
		cnt++;
		break;
	case 2:insert_end();
		cnt++;
		break;
	case 3:insert_before();
		cnt++;
		break;
	case 4:insert_after();
		cnt++;
		break;
	case 5:display();
		break;
	case 6:break;

  }

  }while(ch!=6);

}
void del()
{ int ch;
  do
  {   printf("\n:::::::::DELETE MENU:::::::::");
  printf("\n1.delete at begnning \n2.delete at end\n3.detele node given value\n4.delete node before\n5.delete node after\n6.display\n7.exit\nenter your choice:");
  scanf("%d",&ch);
  switch(ch)
  { 	 case 1:del_beg();
		cnt--;
		break;
	case 2:del_end();
		cnt--;
		break;
	case 3:del_give();
		cnt--;
		break;
	case 4:del_before();
	      cnt--;
	      break;
	case 5:del_after();
		cnt--;
		break;
	case 6:display();
		break;
	case 7:break;
  }

  }while(ch!=7);

}


void insert_beg()
{ New=(node*)malloc(sizeof(node));
  printf("Enter data:");
  scanf("%d",&New->data);
     New->prev=NULL;
     New->next=start;
     start->prev=New;
     start=New;
}
void insert_end()
{ New=(node*)malloc(sizeof(node));
  printf("Enter data:");
  scanf("%d",&New->data);
  New->next=NULL;
  for(temp=start;temp->next!=NULL;temp=temp->next);
  temp->next=New;
  New->prev=New;
}
void insert_before()
{
  int val;
  New=(node*)malloc(sizeof(node));
  printf("\nwhere node:");
  scanf("%d",&val);
  printf("Enter data:");
  scanf("%d",&New->data);
  for(temp=start;temp->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  New->next=temp;
  New->prev=temp->prev;
  temp->prev=New;
  pr->next=New;

}
void insert_after()
{ int val;
  New=(node*)malloc(sizeof(node));
  printf("\nwhere node:");
  scanf("%d",&val);
  printf("Enter data:");
  scanf("%d",&New->data);
  for(temp=start;pr->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  New->next=temp;
  New->prev=pr;
  pr->next=New;
  temp->prev=New;
  pr->next=New;

}
void del_beg()
{ temp=start;
  start=start->next;
  start->prev=NULL;
  free(temp);
}
void del_end()
{  for(temp=start;temp->next->next!=NULL;temp=temp->next);
    det=temp->next;
    temp->next=NULL;
    free(det);
}
void del_before()
{ int val;
  printf("\nwhich node:");
  scanf("%d",&val);
  if(start->next->data==val)
  { temp=start;
    start=start->next;
    start->prev=NULL;
    free(temp);
  }
  else
  {
 for(temp=start;temp->data!=val;temp=temp->next)
 {
   pr=temp;
 }
 det=temp->prev;
 pr->prev->next=temp;
 temp->prev=pr->prev;
 free(det);
}
}
void del_after()
{  int val;
   printf("\nwhere node:");
    scanf("%d",&val);
    for(temp=start;pr->data!=val;temp=temp->next)
  {
   pr=temp;
  }
  pr->next=temp->next;
  temp->next->prev=pr;
  free(temp);
}
void del_give()
{ int val;
  printf("\nEnter node to delete");
  scanf("%d",&val);
  if(start->data==val)
  { temp=start;
   start=start->next;
   start->prev=NULL;
   free(temp);

  }
  else
  {
	 for(temp=start;temp->data!=val;temp=temp->next)
	 {
	 pr=temp;
	 }
  pr->next=temp->next;
  temp->next->prev=pr;
  free(temp);
  }
}
void display()
{ for(temp=start;temp!=NULL;temp=temp->next)
  printf("\ndata: %d",temp->data);

}


